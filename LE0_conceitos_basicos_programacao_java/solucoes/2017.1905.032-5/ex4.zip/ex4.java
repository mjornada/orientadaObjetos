public class ex4 {
	public static void main(String[] args) {
		int i = 123123;
		double d = 8908;
		float f = 175f;
		boolean bool = true;
		char c = 'cwnad';
		byte b = 62453242425;
		short s = 54132123;
		long l = 54L;		
		
		System.out.println(i);
		System.out.println(d);
		System.out.println(f);
		System.out.println(bool);
		System.out.println(c);
		System.out.println(b);				
		System.out.println(s);
		System.out.println(l);
	}
}