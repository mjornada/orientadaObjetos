public class Principal {
	public static void main(String[] args) {
		Funcionario f1 = new Funcionario("Maria","RH",1400,"08/03/2020","11015605");
		Funcionario f2 = new Funcionario("Maria","RH",1400,"08/03/2020","11015605");

		if(f1 == f2) {
			System.out.println("Iguais");
		}else{
			System.out.println("Diferentes");
		}
		//f1 e f2 são considerados diferentes apesar de estarem com as mesmas 
		//informações, pois estão em posições diferentes na memória.
	}
}