public class DateTest{
	public static void main(String[] args){
		Date dt = new Date(15,02,2020);
		dt.displayDate();
		for(int i=0; i<50; i++) {
			dt.nextDay();
			dt.displayDate();
		}
	}	
}