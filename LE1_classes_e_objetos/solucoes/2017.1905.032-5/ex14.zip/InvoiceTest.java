public class InvoiceTest{
	public static void main(String[] args){
		Invoice fatura1 = new Invoice("12302345", "mouse", 2, 10);
		System.out.printf("Número: %s\nDescrição: %s\nQuantidade: %d\nPreço: %.2f\n",fatura1.getNumero(),fatura1.getDescricao(),fatura1.getQuantidade(),fatura1.getPreco());
		System.out.println("Total: "+fatura1.getInvoiceAmount(fatura1.getQuantidade(),fatura1.getPreco()));

		fatura1.setPreco(12.50);
		System.out.println("Total: "+fatura1.getInvoiceAmount(fatura1.getQuantidade(),fatura1.getPreco()));		
	}
}