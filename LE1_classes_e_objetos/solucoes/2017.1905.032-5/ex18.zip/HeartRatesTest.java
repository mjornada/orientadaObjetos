import java.util.Scanner;

public class HeartRatesTest {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);		
		System.out.println("Digite seu nome: ");
		String nome = scanner.nextLine();		
		System.out.println("Digite seu sobrenome: ");
		String sobrenome = scanner.nextLine();
		
		System.out.println("Digite sua data de nascimento: dd/mm/aaaa");
		String data = scanner.nextLine();
		int dia = Integer.parseInt(data.substring(0,2));
		int mes = Integer.parseInt(data.substring(3,5));
		int ano = Integer.parseInt(data.substring(6,10));
		
		HeartRates p1 = new HeartRates(nome, sobrenome, dia, mes, ano);
		System.out.printf("%s %s\n%d/%d/%d\n",p1.getNome(),p1.getSobrenome(),p1.data.getDia(),p1.data.getMes(),p1.data.getAno());
		
		System.out.println("Idade: "+p1.calculaIdade()+" anos");
		System.out.println("Frequencia Cardiaca Maxima: "+p1.frequenciaCardiacaMaxima());
		System.out.printf("Frequencia Cardiaca Alvo: %s",p1.frequenciaCardiacaAlvo());
	}

}
