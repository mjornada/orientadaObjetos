public class EmployeeTest{
	public static void main(String[] args){
		Employee obj1 = new Employee("Maria","da Silva", 3200);
		Employee obj2 = new Employee("Jose","Oliveira", 1400);
		
		System.out.println("Nome: "+obj1.getNome()+" "+obj1.getSobrenome()+"\nSalario anual: "+obj1.getSalario()*12);
		obj1.setSalario(obj1.getSalario()*1.10);
		System.out.printf("Reajuste 10%%: %.2f\n",obj1.getSalario());
		
		System.out.println("Nome: "+obj2.getNome()+" "+obj2.getSobrenome()+"\nSalario anual: "+obj2.getSalario()*12);
		obj2.setSalario(obj2.getSalario()*1.10);
		System.out.printf("Reajuste 10%%: %.2f\n",obj2.getSalario());
	}
}