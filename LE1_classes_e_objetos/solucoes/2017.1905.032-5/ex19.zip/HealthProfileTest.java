import java.util.Scanner;

public class HealthProfileTest {
	public static void main(String[] args) {
		String nome, sobrenome, dtNascimento;
		char sexo;
		int dia, mes, ano;
		float altura, peso;
		
		Scanner scanner = new Scanner(System.in);
		System.out.printf("Informe seus dados abaixo:\nNome: ");
		nome = scanner.nextLine();
		System.out.print("Sobrenome: ");
		sobrenome = scanner.nextLine();		
		System.out.print("Sexo: ");
		sexo = scanner.next().charAt(0);
		System.out.print("Altura: ");
		altura = scanner.nextFloat();
		System.out.print("Peso: ");
		peso = scanner.nextFloat();
		scanner.nextLine();
		System.out.print("Data de nascimento (dd/mm/aaaa): ");
		dtNascimento = scanner.nextLine();
		dia = Integer.parseInt(dtNascimento.substring(0,2));
		mes = Integer.parseInt(dtNascimento.substring(3,5));
		ano = Integer.parseInt(dtNascimento.substring(6,10));

		HealthProfile p1 = new HealthProfile(nome, sobrenome, sexo, altura, peso, dia, mes, ano);
		
		System.out.println("Idade: "+p1.calculaIdade());
		System.out.println("IMC: "+p1.calculaIMC());
		System.out.println("Frequencia cardiaca maxima: "+p1.frequenciaCardiacaMaxima());
		System.out.println("Frequencia cardiaca alvo: "+p1.frequenciaCardiacaAlvo());
	}
}