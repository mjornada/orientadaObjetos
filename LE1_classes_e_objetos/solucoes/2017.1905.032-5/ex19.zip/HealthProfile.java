import java.text.SimpleDateFormat;
import java.util.Date;

public class HealthProfile {
	String nome;
	String sobrenome;
	char sexo;
	float altura;
	float peso;
	Data data;
		
	public HealthProfile(String nome, String sobrenome, char sexo, float altura, float peso, int dia, int mes, int ano) {
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.sexo = sexo;
		this.altura = altura;
		this.peso = peso;
		
		data = new Data(dia, mes, ano);
	}
	
	
	public float calculaIMC() {
		altura = getAltura();
		return getPeso()/(altura*altura);
	}	
	
	public int calculaIdade() {
		int idade=0;
		Date dt = new Date();
		SimpleDateFormat dia = new SimpleDateFormat("dd");
		SimpleDateFormat mes = new SimpleDateFormat("MM");
		SimpleDateFormat ano = new SimpleDateFormat("yyyy");
		int d = Integer.parseInt(dia.format(dt));
		int m = Integer.parseInt(mes.format(dt));
		int a = Integer.parseInt(ano.format(dt));
		
		if(data.getMes()>m || (data.getMes()==m && data.getDia()>=d)) 
			idade =  a-data.getAno();
		else
			idade =  a-data.getAno()+1;
		
		return idade;
	}
	
	public int frequenciaCardiacaMaxima() {
		return 220-calculaIdade();
	}
	
	public String frequenciaCardiacaAlvo() {
		double fcm = frequenciaCardiacaMaxima();
		String s="";
		s += String.format("%.2f ~ %.2f\n",fcm*0.50, fcm*0.85);
		return s;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getSobrenome() {
		return sobrenome;
	}
	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}
	
	public char getSexo() {
		return sexo;
	}
	public void setSexo(char sexo) {
		this.sexo = sexo;
	}
	
	public float getAltura() {
		return altura;
	}
	public void setAltura(float altura) {
		this.altura = altura;
	}
	
	public float getPeso() {
		return peso;
	}
	public void setPeso(float peso) {
		this.peso = peso;
	}	
}