public class Data{
	int dia;
	int mes;
	int ano;
	
	public Data(int dia, int mes, int ano){
		this.dia = dia;
		this.mes = mes;
		this.ano = ano;
	}
	

	public void displayData(){
		System.out.printf("%d/%d/%d\n",getDia(),getMes(),getAno());
	}
	
	public void nextDay() {
		if(anoBissexto()==1 && getMes()==2) {
			if(getDia()<29)
				setDia(getDia()+1);
			else {
				setDia(1);
				if(getMes()<12)
					setMes(getMes()+1);
				else {
					setMes(1);
			 		setAno(getAno()+1);
				}
			}
		} else {
			if(getMes()==1 || getMes()==3 || getMes()==5 || getMes()==7 || getMes()==8 || getMes()==10 || getMes()==12) {
				if(getDia()<31)
					setDia(getDia()+1);
				else {
					setDia(1);
					if(getMes()<12)
						setMes(getMes()+1);
					else {
						setMes(1);
						setAno(getAno()+1);
					}
				}
			} else if(getMes()==2){
				if(getDia()<28)
					setDia(getDia()+1);
				else {
					setDia(1);
					if(getMes()<12)
						setMes(getMes()+1);
					else {
						setMes(1);
						setAno(getAno()+1);
					}
				}
			} else {
				if(getDia()<30)
					setDia(getDia()+1);
				else {
					setDia(1);
					if(getMes()<12)
						setMes(getMes()+1);
					else {
						setMes(1);
						setAno(getAno()+1);
					}
				}
			}
		}
	}
	
	public int anoBissexto() {
		if((getAno()%4==0 && getAno()%100!=0) || getAno()%400==0)
			return 1;
		else
			return 0;
	}
	
	public void setDia(int dia){
		this.dia = dia;
	}
	public int getDia(){
		return dia;
	}
	
	public void setMes(int mes){
		this.mes = mes;
	}
	public int getMes(){
		return mes;
	}
	
	public void setAno(int ano){
		this.ano = ano;
	}
	public int getAno(){
		return ano;
	}
}