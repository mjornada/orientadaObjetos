public class Principal {
	public static void main(String[] args) {
		Funcionario f1 = new Funcionario();

		f1.mostra();
	}
}