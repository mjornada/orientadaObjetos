public class Principal {
	public static void main(String[] args){
		Pessoa p1 = new Pessoa("Maria", 20);
		System.out.printf("Nome: %s\nIdade: %s\n",p1.getNome(),p1.getIdade());
		p1.fazAniversario();
		System.out.printf("Nome: %s\nIdade: %s\n",p1.getNome(),p1.getIdade());
		System.out.println();
		
		Porta porta1 = new Porta(true,"branca",200,120,80);
		System.out.printf("%b %s %d %d %d\n", porta1.estaAberta(), porta1.getCor(), porta1.getDimensaoX(), porta1.getDimensaoY(), porta1.getDimensaoZ());
		porta1.setCor("verde");
		porta1.setAberta(false);		
		System.out.printf("%b %s %d %d %d\n", porta1.estaAberta(), porta1.getCor(), porta1.getDimensaoX(), porta1.getDimensaoY(), porta1.getDimensaoZ());
		System.out.println();
		
		Porta porta2 = new Porta(true,"preta",200,120,80);
		Porta porta3 = new Porta(true,"amarela",200,120,80);
		Casa c1 = new Casa("azul",porta1, porta2, porta3);
		System.out.println("Porta(s) aberta(s): " + c1.quantasPortasEstaoAbertas());
		
	}	
}