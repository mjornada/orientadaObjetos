public class Porta {
	boolean aberta;
	String cor;
	int dimensaoX;
	int dimensaoY;
	int dimensaoZ;
	
	Porta(boolean aberta, String cor, int dimensaoX, int dimensaoY, int dimensaoZ){
		this.aberta = aberta;
		this. cor = cor;
		this.dimensaoX = dimensaoX;
		this.dimensaoY = dimensaoY;
		this.dimensaoZ = dimensaoZ;
	}
	
	public boolean getAberta(){
		return aberta;
	}	
	public void setAberta(boolean aberta){
		this.aberta = aberta;
	}
	
	public String getCor(){
		return cor;
	}
	public void setCor(String cor){
		this.cor = cor;
	}

	public int getDimensaoX(){
		return dimensaoX;
	}	
	public void setDimensaoX(int dimensaoX){
		this.dimensaoX = dimensaoX;
	}
	
	public int getDimensaoY(){
		return dimensaoY;
	}	
	public void setDimensaoY(int dimensaoY){
		this.dimensaoY = dimensaoY;
	}
	
	public int getDimensaoZ(){
		return dimensaoZ;
	}	
	public void setDimensaoZ(int dimensaoZ){
		this.dimensaoZ = dimensaoZ;
	}
	
	boolean fecha(){
		if(this.getAberta())
			return true;
		else 
			return false;
	}
	void pinta(String s){
		setCor(s);
	}
	
	boolean estaAberta(){
		return getAberta();
	}
}