public class Casa {
	String cor;
	Porta porta1, porta2, porta3;
	
	Casa(String cor, Porta porta1, Porta porta2, Porta porta3) {
		this.cor = cor;
		this.porta1 = porta1;
		this.porta2 = porta2;
		this.porta3 = porta3;
	}
	
	public String getCor(){
		return cor;
	}	
	public void setCor(String cor){
		this.cor = cor;
	}
	
	void pinta(String s){
		setCor(s);
	}
	
	int quantasPortasEstaoAbertas(){
		int contador = 0;
		if(porta1.estaAberta())
			contador +=1;
		if(porta2.estaAberta())
			contador +=1;
		if(porta3.estaAberta())
			contador +=1;
		
		return contador;
	}
	
}