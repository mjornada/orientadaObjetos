public class Funcionario {
	String nome;
	String departamento;
	double salario;
	String dataDeEntrada;
	String RG;

	void recebeAumento(double parametro) {
		salario = salario + parametro;
	}

	double calculaGanhoAnual() {
		return salario * 12;
	}
	
}