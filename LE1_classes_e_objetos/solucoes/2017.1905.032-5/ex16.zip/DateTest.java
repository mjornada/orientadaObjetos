public class DateTest{
	public static void main(String[] args){
		Date dt = new Date(26,03,2020);
		dt.displayDate();
	}	
}