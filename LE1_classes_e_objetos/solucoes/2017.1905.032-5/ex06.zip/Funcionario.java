public class Funcionario {
	String nome;
	String departamento;
	String rg;
	double salario;
	//String dataDeEntrada;
	Data data;

	Funcionario(String nome, String departamento, String rg, int salario, int dia, int mes, int ano) {
		this.nome = nome;
		this.departamento = departamento;
		this.rg = rg;
		this.salario = salario;
		
		data = new Data(dia, mes, ano);
	}
	
	void recebeAumento(double parametro) {
		salario = salario + parametro;
	}

	double calculaGanhoAnual() {
		return salario * 12;
	}
	
	void mostra(Data data) {
		System.out.print("Nome: "+nome + "\nDepartamento: "+departamento + "\nSalario: "+salario + "\nData de Entrada: "+data.dia+"/"+data.mes+"/"+data.ano + "\nRG: "+rg);
	}
}