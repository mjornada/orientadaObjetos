public class Principal {
	public static void main(String[] args) {
		Funcionario f1 = new Funcionario("Maria","RH","11015605",1400, 26, 03, 2020);
		System.out.printf("Nome: %s\nDepartamento: %s\nRG: %s\nSalario: %s\nData de entrada: %d/%d/%d\n", f1.nome, f1.departamento,f1.rg,f1.salario,f1.data.dia,f1.data.mes,f1.data.ano);
	}
}