public class Rectangle {
	float length = 1;
	float width = 1;
	
	public Rectangle(float length, float width) {
		this.length = length;
		this.width = width;
	}
	
	
	public float calculaPerimetro(){
		return calculaArea()*2;
	}
	
	public float calculaArea(){
		return length*width;
	}
	
	
	public void setLength(float length){
		if(length>0.0 && length<20.0)
			this.length = length;
	}
	public float getLength(){
		return length;
	}
	
	public void setWidth(float width){
		if(width>0.0 && width<20.0)
			this.width = width;
	}
	public float getWidth(){
		return width;
	}	
}