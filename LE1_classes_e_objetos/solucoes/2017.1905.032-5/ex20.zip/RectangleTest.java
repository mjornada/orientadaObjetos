public class RectangleTest {
	public static void main(String[] args) {
		Rectangle r = new Rectangle(2.0f,4.5f);
		
		System.out.printf("Retangulo: %.2f x %.2f\n", r.getLength(), r.getWidth());
		System.out.println("Perimetro: "+r.calculaPerimetro());
		System.out.println("Area: "+r.calculaArea());
	}
}