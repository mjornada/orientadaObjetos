public class AccountTest{
	public static void main(String[] args){
		Account conta1 = new Account(-2);
		System.out.println(conta1.getBalance());
		
		Account conta2 = new Account(100);
		System.out.println(conta2.getBalance());
		
		conta1.credit(250);
		System.out.println(conta1.getBalance());
		conta2.debit(120);
		System.out.println(conta2.getBalance());
		conta2.debit(99);
		System.out.println(conta2.getBalance());
	}
}