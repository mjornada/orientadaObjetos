public class Account{
	private double balance;
	
	Account(double initialBalance){
		if(initialBalance > 0)
			this.balance = initialBalance;
	}
	
	public double getBalance(){
		return balance;
	}
	public void setBalance(double balance){
		this.balance = balance;
	}
	
	public void credit(double amount){
		setBalance(amount);
	}
	
	public void debit(double valor){
		if(valor > balance)
			System.out.println("Debit amount exceeded account balance");
		else
			balance -= valor;
	}	
}