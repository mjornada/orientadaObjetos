public class GradeBook {
	private String courseName;
	private String instructorName;
	
	GradeBook(String courseName){
		this.courseName = courseName;
		this.instructorName = "Not defined yet";
	}

	GradeBook(String courseName, String instructorName){
		this.courseName = courseName;
		this.instructorName = instructorName;
	}

	public String getCourseName(){
		return courseName;
	}
	public void setCourseName(String courseName){
		this.courseName = courseName;
	}

	public String getInstructorName(){
		return instructorName;
	}
	public void setInstructorName(String instructorName){
		this.instructorName = instructorName;
	}

	public void displayMessage(){
		System.out.println("Boas vindas!");
		System.out.println("Nome do curso: " + getCourseName());
		System.out.println("Nome do professor: " + getInstructorName());
	}
}