public class GradeBookTest{
	public static void main(String[] args){
		GradeBook grade1 = new GradeBook("Ingles");
		GradeBook grade2 = new GradeBook("Portugues", "Espanhol");
		grade1.displayMessage();
		grade2.displayMessage();
	
		grade1.setCourseName("English");
		grade2.setCourseName("Spanish");
		grade2.setInstructorName("Portuguese");
		grade1.displayMessage();
		grade2.displayMessage();
	}	
}