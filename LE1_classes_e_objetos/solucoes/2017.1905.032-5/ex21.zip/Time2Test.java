public class Time2Test {
	public static void main(String[] args) {
		Time2 t = new Time2(14,30,10);
		System.out.println("Hora: "+t.toString());
		System.out.println("Hora universal: "+t.toUniversalString());
	}
}