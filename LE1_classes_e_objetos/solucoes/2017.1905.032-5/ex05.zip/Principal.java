public class Principal {
	public static void main(String[] args) {
		Funcionario funcionario = new Funcionario("Maria","RH",1400,"08/03/2020","11015605");
		Funcionario f1 = funcionario;
		Funcionario f2 = funcionario;
		if(f1 == f2) {
			System.out.println("Iguais");
		}else{
			System.out.println("Diferentes");
		}
		//f1 e f2 são considerados iguais, pois estão referenciando o mesmo endereço de memória.
	}
}