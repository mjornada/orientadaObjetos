public class Funcionario {
	String nome;
	String departamento;
	double salario;
	String dataDeEntrada;
	String rg;

	Funcionario(String nome, String departamento, double salario, String dataDeEntrada, String rg) {
		this.departamento = departamento;
		salario = 0;
		this.dataDeEntrada = dataDeEntrada;
		this.rg = rg;
	}

	void recebeAumento(double parametro) {
		salario = salario + parametro;
	}

	double calculaGanhoAnual() {
		return salario * 12;
	}
	
	void mostra() {
		System.out.print("Nome: "+nome + "\nDepartamento: "+departamento + "\nSalario: "+salario + "\nData de Entrada: "+dataDeEntrada + "\nRG: "+rg);
	}
}