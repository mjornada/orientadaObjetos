public class SavingsAccount {
	static double annualInterestRate;
	private double savingsBalance;
	
	public SavingsAccount(double savingsBalance) {
		this.savingsBalance = savingsBalance;
	}
	
	
	public void calculateMonthlyInterest() {
		setSavingsBalance(savingsBalance+(savingsBalance*annualInterestRate)/12);
	}
	
	public static void modifyInterestRate(double valor) {
		annualInterestRate = valor;
	}
	
	
	public void setAnnualInterestRate(double annualInterestRate) {
		modifyInterestRate(annualInterestRate);
	}
	public double getAnnualInterestRate() {
		return annualInterestRate;
	}
	
	public void setSavingsBalance(double savingsBalance) {
		this.savingsBalance = savingsBalance;
	}
	public double getSavingsBalance() {
		return savingsBalance;
	}
	
}